# Project-specific R8/ProGuard rules.
# Keep this file for release builds; add keep rules here if reflection/JNI requires them.
