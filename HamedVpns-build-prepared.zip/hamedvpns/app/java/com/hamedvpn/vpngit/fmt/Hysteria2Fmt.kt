package com.hamedvpn.vpngit.fmt

import com.hamedvpn.vpngit.AppConfig
import com.hamedvpn.vpngit.dto.entities.ProfileItem
import com.hamedvpn.vpngit.enums.EConfigType
import com.hamedvpn.vpngit.enums.NetworkType
import com.hamedvpn.vpngit.extension.idnHost
import com.hamedvpn.vpngit.extension.isNotNullEmpty
import com.hamedvpn.vpngit.extension.nullIfBlank
import com.hamedvpn.vpngit.util.Utils
import java.net.URI

object Hysteria2Fmt : FmtBase() {
    
    fun parse(str: String): ProfileItem {
        val config = ProfileItem.create(EConfigType.HYSTERIA2)

        val uri = URI(Utils.fixIllegalUrl(str))
        config.remarks = Utils.decodeURIComponent(uri.fragment.orEmpty()).let { it.ifEmpty { "none" } }
        config.server = uri.idnHost
        config.serverPort = uri.port.toString()
        config.password = uri.userInfo
        config.security = AppConfig.TLS
        config.network = NetworkType.HYSTERIA.type

        if (!uri.rawQuery.isNullOrEmpty()) {
            val queryParam = getQueryParam(uri)

            getItemFormQuery(config, queryParam)

            config.security = queryParam["security"] ?: AppConfig.TLS
            config.obfsPassword = queryParam["obfs-password"]
            config.portHopping = queryParam["mport"]
            if (config.portHopping.isNotNullEmpty()) {
                config.portHoppingInterval = queryParam["mportHopInt"]
            }
            config.pinnedCA256 = queryParam["pinSHA256"]

        }

        return config
    }

    
    fun toUri(config: ProfileItem): String {
        val dicQuery = HashMap<String, String>()

        config.security.let { if (it != null) dicQuery["security"] = it }
        config.sni?.nullIfBlank()?.let { dicQuery["sni"] = it }
        config.alpn?.nullIfBlank()?.let { dicQuery["alpn"] = it }
        config.insecure.let { dicQuery["insecure"] = if (it == true) "1" else "0" }

        if (config.obfsPassword.isNotNullEmpty()) {
            dicQuery["obfs"] = "salamander"
            dicQuery["obfs-password"] = config.obfsPassword.orEmpty()
        }
        if (config.portHopping.isNotNullEmpty()) {
            dicQuery["mport"] = config.portHopping.orEmpty()
        }
        if (config.portHoppingInterval.isNotNullEmpty()) {
            val rawInterval = config.portHoppingInterval?.trim().nullIfBlank()
            val interval = if (rawInterval == null) {
                null
            } else {
                val singleValue = rawInterval.toIntOrNull()
                if (singleValue != null) {
                    if (singleValue < 5) {
                        null
                    } else {
                        rawInterval
                    }
                } else {
                    val parts = rawInterval.split('-')
                    if (parts.size == 2) {
                        val start = parts[0].trim().toIntOrNull()
                        val end = parts[1].trim().toIntOrNull()
                        if (start != null && end != null) {
                            val minStart = maxOf(5, start)
                            val minEnd = maxOf(minStart, end)
                            (minStart + minEnd) / 2
                        } else {
                            null
                        }
                    } else {
                        null
                    }
                }
            }
            if (interval != null) {
                dicQuery["mportHopInt"] = interval.toString()
            }
        }
        if (config.pinnedCA256.isNotNullEmpty()) {
            dicQuery["pinSHA256"] = config.pinnedCA256.orEmpty()
        }

        return toUri(config, config.password, dicQuery)
    }
}
