package com.hamedvpn.vpngit.handler

import android.text.TextUtils
import com.hamedvpn.vpngit.AppConfig
import com.hamedvpn.vpngit.dto.entities.SubscriptionCache
import com.hamedvpn.vpngit.dto.entities.SubscriptionItem
import com.hamedvpn.vpngit.util.LogUtil

object AutoConnectManager {

    fun getOrInitSubscriptionId(): String {
        var panelUrl = MmkvManager.decodeSettingsString(AppConfig.PREF_PANEL_URL)
        var panelApiKey = MmkvManager.decodeSettingsString(AppConfig.PREF_PANEL_API_KEY)

        // Use defaults if not configured
        if (panelUrl.isNullOrBlank()) panelUrl = AppConfig.DEFAULT_PANEL_URL
        if (panelApiKey.isNullOrBlank()) panelApiKey = AppConfig.DEFAULT_PANEL_API_KEY

        val subUrl = "${panelUrl.trimEnd('/')}/api/subscription?key=$panelApiKey"

        // Find or create subscription
        val subscriptions = MmkvManager.decodeSubscriptions()
        val existing = subscriptions.find { it.subscription.url == subUrl }

        return if (existing != null) {
            if (!existing.subscription.enabled) {
                existing.subscription.enabled = true
                MmkvManager.encodeSubscription(existing.guid, existing.subscription)
            }
            existing.guid
        } else {
            val subItem = SubscriptionItem().apply {
                remarks = "V2RayNG Panel"
                url = subUrl
                enabled = true
                autoUpdate = true
                updateInterval = 60
            }
            MmkvManager.encodeSubscription("", subItem)
            val updatedSubs = MmkvManager.decodeSubscriptions()
            updatedSubs.lastOrNull()?.guid ?: ""
        }
    }

    fun ensureSubscription(): String {
        val guid = getOrInitSubscriptionId()
        if (guid.isBlank()) return ""

        // Always fetch fresh configs from panel
        try {
            val subItem = MmkvManager.decodeSubscription(guid) ?: return guid
            val result = AngConfigManager.updateConfigViaSub(SubscriptionCache(guid, subItem))
            LogUtil.i(AppConfig.TAG, "AutoConnectManager: Fetch result - configCount=${result.configCount}, success=${result.successCount}, failure=${result.failureCount}, skip=${result.skipCount}")
        } catch (e: Exception) {
            LogUtil.e(AppConfig.TAG, "AutoConnectManager: Failed to fetch from panel", e)
        }

        return guid
    }

    fun refreshBatch(subId: String): List<String> {
        if (subId.isBlank()) return emptyList()

        val subItem = MmkvManager.decodeSubscription(subId) ?: return emptyList()
        if (!subItem.enabled) return emptyList()

        val servers = MmkvManager.decodeServerList(subId)
        LogUtil.i(AppConfig.TAG, "AutoConnectManager: refreshBatch for $subId found ${servers.size} servers")
        return servers
    }

    fun isPanelConfigured(): Boolean {
        // Always configured because we have default panel values
        return true
    }
}
