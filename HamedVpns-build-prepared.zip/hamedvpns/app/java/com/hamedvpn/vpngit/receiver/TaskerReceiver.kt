package com.hamedvpn.vpngit.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.text.TextUtils
import com.hamedvpn.vpngit.AppConfig
import com.hamedvpn.vpngit.core.CoreServiceManager
import com.hamedvpn.vpngit.util.LogUtil

class TaskerReceiver : BroadcastReceiver() {

    
    override fun onReceive(context: Context, intent: Intent?) {
        try {
            val bundle = intent?.getBundleExtra(AppConfig.TASKER_EXTRA_BUNDLE)
            val switch = bundle?.getBoolean(AppConfig.TASKER_EXTRA_BUNDLE_SWITCH, false)
            val guid = bundle?.getString(AppConfig.TASKER_EXTRA_BUNDLE_GUID).orEmpty()

            if (switch == null || TextUtils.isEmpty(guid)) {
                return
            } else if (switch) {
                if (guid == AppConfig.TASKER_DEFAULT_GUID) {
                    CoreServiceManager.startVServiceFromToggle(context)
                } else {
                    CoreServiceManager.startVService(context, guid)
                }
            } else {
                CoreServiceManager.stopVService(context)
            }
        } catch (e: Exception) {
            LogUtil.e(AppConfig.TAG, "Error processing Tasker broadcast", e)
        }
    }
}

